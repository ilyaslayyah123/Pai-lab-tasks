from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

responses = {
    "hi": "Hello! Welcome to  Hospital. How can I assist you today?",
    "what are your timings": "Our hospital is open 24/7, but OPD services are available from 9 AM to 5 PM.",
    "do you have cardiology department": "Yes, we have a full-fledged cardiology department with experienced doctors.",
    "how can I book an appointment": "You can book an appointment by calling us at (123) 456-7890 or visiting our website.",
    "who are the top doctors": "Our top doctors include Dr. Smith (Cardiology), Dr. John (Neurology), and Dr. Emily (Pediatrics).",
    "where is the hospital located": "We are located at 123 Main Street, New York, NY.",
    "contact number": "You can contact us at (123) 456-7890."
}

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/get", methods=["POST"])
def get_bot_response():
    user_input = request.form["msg"].lower()
    response = responses.get(user_input, "Sorry, I didn't understand that. Could you rephrase?")
    return jsonify({"response": response})

if __name__ == "__main__":
    app.run(debug=True)

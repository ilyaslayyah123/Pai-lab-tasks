import requests

def get_ai_response(query):
    try:
        url = "https://api.together.xyz/v1/chat/completions"
        headers = {
            "Authorization": "Bearer tgp_v1_Gzm5z5KOVxCyQvllttXRoIrFgfUuNPQJhjAqK90Ow2I",
            "Content-Type": "application/json"
        }

        payload = {
            "model": "mistralai/Mistral-7B-Instruct-v0.1",
            "messages": [
                {"role": "user", "content": query}
            ],
            "temperature": 0.7
        }

        response = requests.post(url, headers=headers, json=payload)
        response.raise_for_status()
        reply = response.json()["choices"][0]["message"]["content"]
        return reply

    except requests.exceptions.RequestException as e:
        return f" API Request Error: {e}"
    except Exception as e:
        return f" Unexpected Error: {e}"

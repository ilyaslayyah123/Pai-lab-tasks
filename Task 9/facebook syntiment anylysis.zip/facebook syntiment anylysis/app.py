from flask import Flask, render_template, request
import pickle

app = Flask(__name__)
with open('sentiment_model.pkl', 'rb') as f:
    model = pickle.load(f)

with open('tfidf_vectorizer.pkl', 'rb') as f:
    vectorizer = pickle.load(f)

@app.route('/', methods=['GET', 'POST'])
def index():
    sentiment = None
    if request.method == 'POST':
        text = request.form['comment']
        vector = vectorizer.transform([text])
        prediction = model.predict(vector)[0]
        sentiment = prediction
    return render_template('index.html', sentiment=sentiment)

if __name__ == '__main__':
    app.run(debug=True)
